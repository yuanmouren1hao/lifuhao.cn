{foreach $sidebar as $module}
{template:module}
{/foreach}